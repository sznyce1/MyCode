#pragma once
class Kwadrat
{
public:
	void seta(float c);
	float geta();	
	float obliczPole();
	Kwadrat();
	Kwadrat(float a);
	
private:
	float a;	
};

