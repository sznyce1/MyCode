#include "Kwadrat.h"
void Kwadrat::seta(float c)
{
	a = c;
}
float Kwadrat::geta() {
	return a;
}
float Kwadrat::obliczPole() {
	return a * a;
}
Kwadrat::Kwadrat() {
	a = 1;
}
Kwadrat::Kwadrat(float a) {
	Kwadrat::a = a;
}