#pragma once
#include "Kwadrat.h"
class Szescian :   public Kwadrat
{
public:
	Szescian(float a);
	Szescian();
	float obliczPole();
	float obliczObjetisc();


private:
	
};

