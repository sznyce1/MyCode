#pragma once
#include "Kolo.h"
class Kula :    public Kolo
{
public:
	Kula();
	Kula(double r);
	double Obliczpole();
	double Obliczobjetosc();
private:

};

